﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Exam.ViTube
{
    public class ViTubeRepository : IViTubeRepository
    {
        private Dictionary<string, User> users = new Dictionary<string, User>();

        private Dictionary<string, Video> videos = new Dictionary<string, Video>();

        private Dictionary<string, HashSet<string>> usersWatchedVideos = new Dictionary<string, HashSet<string>>();

        private Dictionary<string, HashSet<string>> usersRatedVideos = new Dictionary<string, HashSet<string>>();

        private HashSet<User> passiveUsers = new HashSet<User>();

        public bool Contains(User user)
        {
            return this.users.ContainsKey(user.Id);
        }

        public bool Contains(Video video)
        {
            return this.videos.ContainsKey(video.Id);
        }

        public void DislikeVideo(User user, Video video)
        {
            if (!this.users.ContainsKey(user.Id) || !this.videos.ContainsKey(video.Id))
            {
                throw new ArgumentException();
            }

            this.videos[video.Id].Dislikes = this.videos[video.Id].Dislikes + 1;
            this.usersRatedVideos[user.Id].Add(video.Id);
            this.passiveUsers.Remove(user);
        }

        public IEnumerable<User> GetPassiveUsers()
        {
            return this.passiveUsers;
        }

        public IEnumerable<User> GetUsersByActivityThenByName()
        {
            return this.users.Values
                .OrderByDescending(u => this.usersWatchedVideos[u.Id].Count)
                .ThenByDescending(u => this.usersRatedVideos[u.Id].Count)
                .ThenBy(u => u.Username);
        }

        public IEnumerable<Video> GetVideos()
        {
            return this.videos.Values;
        }

        public IEnumerable<Video> GetVideosOrderedByViewsThenByLikesThenByDislikes()
        {
            return this.videos.Values
                .OrderByDescending(v => v.Views)
                .ThenByDescending(v => v.Likes)
                .ThenBy(v => v.Dislikes);
        }

        public void LikeVideo(User user, Video video)
        {
            if (!this.users.ContainsKey(user.Id) || !this.videos.ContainsKey(video.Id))
            {
                throw new ArgumentException();
            }

            this.videos[video.Id].Likes = this.videos[video.Id].Likes + 1;
            this.usersRatedVideos[user.Id].Add(video.Id);
            this.passiveUsers.Remove(user);
        }

        public void PostVideo(Video video)
        {
            this.videos.Add(video.Id, video);
        }

        public void RegisterUser(User user)
        {
            this.users.Add(user.Id, user);
            this.usersWatchedVideos.Add(user.Id, new HashSet<string>());
            this.usersRatedVideos.Add(user.Id, new HashSet<string>());
            this.passiveUsers.Add(user);
        }

        public void WatchVideo(User user, Video video)
        {
            if (!this.users.ContainsKey(user.Id) || !this.videos.ContainsKey(video.Id))
            {
                throw new ArgumentException();
            }

            this.videos[video.Id].Views = this.videos[video.Id].Views + 1;
            this.usersWatchedVideos[user.Id].Add(video.Id);
            this.passiveUsers.Remove(user);
        }
    }
}
